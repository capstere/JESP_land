﻿# Write-WorksheetSignatures (EPPlus) har ersatts av Invoke-WorksheetSignature_OpenXml i OpenXmlHelpers.ps1!!!!!

function Get-DataSheets { param([OfficeOpenXml.ExcelPackage]$Pkg)
    $all = @($Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne "Worksheet Instructions" })
    if ($all.Count -gt 1) { return $all | Select-Object -Skip 1 } else { return @() }
}

function Test-SignatureFormat {
    param([string]$Text)
    $raw = ($Text + '')
    $trim = $raw.Trim()
    $parts = $trim -split '\s*,\s*'
    $name = if ($parts.Count -ge 1) { $parts[0] } else { '' }
    $sign = if ($parts.Count -ge 2) { $parts[1] } else { '' }
    $date = if ($parts.Count -ge 3) { $parts[2] } else { '' }
    $dateOk = $false
    if ($date) { if ($date -match '^\d{4}-\d{2}-\d{2}$' -or $date -match '^\d{8}$') { $dateOk = $true } }
    [pscustomobject]@{ Raw=$raw; Name=$name; Sign=$sign; Date=$date; Parts=$parts.Count; DateOk=$dateOk; LooksOk=($name -ne '' -and $sign -ne '') }
}

function Confirm-SignatureInput { param([string]$Text)
    $info = Test-SignatureFormat $Text
    $hint = @()
    if (-not $info.Name) { $hint += 'Namn verkar saknas' }
    if (-not $info.Sign) { $hint += 'Signatur verkar saknas' }
    $hasWarning = ($hint.Count -gt 0)

    # ── Custom Form ──
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text            = 'Seal Test — Bekräfta signatur'
    $dlg.StartPosition   = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox     = $false
    $dlg.MinimizeBox     = $false
    $dlg.Size            = New-Object System.Drawing.Size(480, 340)
    $dlg.Font            = New-Object System.Drawing.Font('Segoe UI', 10)

    # Header panel
    $pHead = New-Object System.Windows.Forms.Panel
    $pHead.Dock      = 'Top'
    $pHead.Height    = 52
    $pHead.BackColor = [System.Drawing.Color]::SteelBlue
    $lblHead = New-Object System.Windows.Forms.Label
    $lblHead.Text      = [char]0x270F + '  Seal Test — Signatur'
    $lblHead.ForeColor = [System.Drawing.Color]::White
    $lblHead.Font      = New-Object System.Drawing.Font('Segoe UI Semibold', 13)
    $lblHead.AutoSize  = $false
    $lblHead.Dock      = 'Fill'
    $lblHead.Padding   = New-Object System.Windows.Forms.Padding(12, 0, 0, 0)
    $lblHead.TextAlign = 'MiddleLeft'
    $pHead.Controls.Add($lblHead)

    # Content panel
    $pContent = New-Object System.Windows.Forms.Panel
    $pContent.Dock    = 'Fill'
    $pContent.Padding = New-Object System.Windows.Forms.Padding(24, 16, 24, 8)

    $nl = [Environment]::NewLine
    $lblInfo = New-Object System.Windows.Forms.Label
    $lblInfo.Dock     = 'Top'
    $lblInfo.AutoSize = $false
    $lblInfo.Height   = 100
    $lblInfo.Font     = New-Object System.Drawing.Font('Segoe UI', 10)
    $lblInfo.Text     = "Namn:           $($info.Name)${nl}Signatur:      $($info.Sign)${nl}Datum:          $($info.Date)"

    $lblStatus = New-Object System.Windows.Forms.Label
    $lblStatus.Dock     = 'Top'
    $lblStatus.AutoSize = $false
    $lblStatus.Height   = 36
    $lblStatus.Font     = New-Object System.Drawing.Font('Segoe UI', 9.5)
    if ($hasWarning) {
        $lblStatus.Text      = [char]0x26A0 + '  ' + ($hint -join ', ')
        $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(180, 80, 80)
    } else {
        $lblStatus.Text      = [char]0x2705 + '  Ser bra ut.'
        $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(40, 120, 40)
    }

    $lblQuestion = New-Object System.Windows.Forms.Label
    $lblQuestion.Dock     = 'Top'
    $lblQuestion.AutoSize = $false
    $lblQuestion.Height   = 30
    $lblQuestion.Text     = 'Vill du skriva denna signatur i alla aktiva Seal Test-blad?'
    $lblQuestion.Font     = New-Object System.Drawing.Font('Segoe UI', 9.5, [System.Drawing.FontStyle]::Italic)

    $pContent.Controls.Add($lblQuestion)
    $pContent.Controls.Add($lblStatus)
    $pContent.Controls.Add($lblInfo)

    # Button panel — FlowLayoutPanel höger-till-vänster (oberoende av fönsterstorlek)
    $pBtn = New-Object System.Windows.Forms.FlowLayoutPanel
    $pBtn.Dock          = 'Bottom'
    $pBtn.Height        = 52
    $pBtn.FlowDirection = 'RightToLeft'
    $pBtn.Padding       = New-Object System.Windows.Forms.Padding(16, 8, 16, 8)
    $pBtn.WrapContents  = $false

    $btnNo = New-Object System.Windows.Forms.Button
    $btnNo.Text         = 'Avbryt'
    $btnNo.Width        = 100
    $btnNo.Height       = 34
    $btnNo.Margin       = New-Object System.Windows.Forms.Padding(0)
    $btnNo.DialogResult = [System.Windows.Forms.DialogResult]::No

    $btnYes = New-Object System.Windows.Forms.Button
    $btnYes.Text         = 'Ja, signera'
    $btnYes.Width        = 120
    $btnYes.Height       = 34
    $btnYes.Margin       = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $btnYes.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    try { Set-AccentButton $btnYes -Primary } catch {
        $btnYes.BackColor = [System.Drawing.Color]::SteelBlue
        $btnYes.ForeColor = [System.Drawing.Color]::White
        $btnYes.FlatStyle = 'Flat'
    }

    # RightToLeft: först tillagd = längst till höger
    $pBtn.Controls.Add($btnNo)
    $pBtn.Controls.Add($btnYes)

    $dlg.AcceptButton = $btnYes
    $dlg.CancelButton = $btnNo
    $dlg.Controls.Add($pContent)
    $dlg.Controls.Add($pBtn)
    $dlg.Controls.Add($pHead)

    $res = $dlg.ShowDialog()
    return ($res -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Normalize-Signature {
    param([string]$s)
    if (-not $s) { return '' }
    $x = $s.Trim().ToLowerInvariant()
    $x = [regex]::Replace($x, '\s+', ' ')
    $x = $x -replace '\s*,\s*', ','
    return $x
}
 
function Get-SignatureSetForDataSheets {
    param([OfficeOpenXml.ExcelPackage]$Pkg)
    $result = [pscustomobject]@{
        RawFirst  = $null
        NormSet   = New-Object 'System.Collections.Generic.HashSet[string]'
        Occ       = @{}
        RawByNorm = @{} 
    }
    if (-not $Pkg) { return $result }

    foreach ($ws in ($Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' })) {
        $h3 = ($ws.Cells['H3'].Text + '').Trim()
        if ($h3 -match '^[0-9]') {
            $raw = ($ws.Cells['B47'].Text + '').Trim()
            if ($raw) {
                $norm = Normalize-Signature $raw
                [void]$result.NormSet.Add($norm)
                if (-not $result.RawFirst) { $result.RawFirst = $raw }
                if (-not $result.Occ.ContainsKey($norm)) {
                    $result.Occ[$norm] = New-Object 'System.Collections.Generic.List[string]'
                }
                if (-not $result.RawByNorm.ContainsKey($norm)) {
                    $result.RawByNorm[$norm] = $raw
                }
                [void]$result.Occ[$norm].Add($ws.Name)
            }
        } elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/?A|NA|Tomt( innehåll)?)$') {
            break
        }
    }
    return $result
}

function UrlEncode([string]$s){ try { [System.Uri]::EscapeDataString($s) } catch { $s } }

function Get-BatchNumberFromSealFile([string]$Path){
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    if (-not (Load-EPPlus)) { return $null }
    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
        foreach ($ws in (Get-DataSheets $pkg)) {
            $txt = ($ws.Cells['D2'].Text + '').Trim()   # Batchnummer från D2
            if ($txt) { return $txt }
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa Batch # från Seal-fil: $($_.Exception.Message)" 'Warn'
    } finally { if ($pkg) { try { $pkg.Dispose() } catch {} } }
    return $null
}

function Update-BatchLink {
    if (-not (Get-Variable -Name slBatchLink -Scope Script -ErrorAction SilentlyContinue) -and -not (Get-Variable -Name slBatchLink -Scope Global -ErrorAction SilentlyContinue)) { return }
    try {
        $selNeg = Get-CheckedFilePath $clbNeg
        $selPos = Get-CheckedFilePath $clbPos
        $bnNeg  = if ($selNeg) { Get-BatchNumberFromSealFile $selNeg } else { $null }
        $bnPos  = if ($selPos) { Get-BatchNumberFromSealFile $selPos } else { $null }
        $lsp    = $txtLSP.Text.Trim()
        $mismatch = ($bnNeg -and $bnPos -and ($bnNeg -ne $bnPos))
        if ($mismatch) {
            $slBatchLink.Text        = 'SharePoint: mismatch'
            $slBatchLink.Enabled     = $false
            $slBatchLink.Tag         = $null
            $slBatchLink.ToolTipText = "NEG: $bnNeg  |  POS: $bnPos"
            return
        }
        $batch = if ($bnPos) { $bnPos } elseif ($bnNeg) { $bnNeg } else { $null }
        if ($batch) {
            $url = $SharePointBatchLinkTemplate -replace '\{BatchNumber\}', (UrlEncode $batch) -replace '\{LSP\}', (UrlEncode $lsp)

            $slBatchLink.Text        = "SharePoint: $batch"
            $slBatchLink.Enabled     = $true
            $slBatchLink.Tag         = $url
            $slBatchLink.ToolTipText = $url
        } else {
            $slBatchLink.Text        = 'SharePoint: —'
            $slBatchLink.Enabled     = $false
            $slBatchLink.Tag         = $null
            $slBatchLink.ToolTipText = 'Direktlänk aktiveras när Batch# hittas i sökt LSP.'
        }
    } catch {
        Gui-Log "⚠️ Kunde inte uppdatera SharePoint-länk: $($_.Exception.Message)" 'Warn'
    }
}

# =============================================================
# Worksheet-signatur  (Sammanställning / Granskning)
# =============================================================

function Confirm-WorksheetSignInput {
    param([string]$FullName, [string]$SignDate, [string[]]$Targets)
    $safeTargets = @()
    if ($Targets) {
        foreach ($t in $Targets) {
            $line = ($t + '').Trim()
            if (-not [string]::IsNullOrWhiteSpace($line)) { $safeTargets += $line }
        }
    }

    # ── Custom Form ──
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text            = 'Worksheet — Bekräfta signatur'
    $dlg.StartPosition   = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox     = $false
    $dlg.MinimizeBox     = $false
    $dlg.Font            = New-Object System.Drawing.Font('Segoe UI', 10)

    # Dynamisk höjd baserat på antal flikar
    $tabCount  = [Math]::Max($safeTargets.Count, 1)
    $dlgHeight = [Math]::Min(520, 260 + ($tabCount * 22))
    $dlg.Size  = New-Object System.Drawing.Size(520, $dlgHeight)

    # Header panel
    $pHead = New-Object System.Windows.Forms.Panel
    $pHead.Dock      = 'Top'
    $pHead.Height    = 52
    $pHead.BackColor = [System.Drawing.Color]::SteelBlue
    $lblHead = New-Object System.Windows.Forms.Label
    $lblHead.Text      = [char]0x2611 + '  Worksheet — Signatur'
    $lblHead.ForeColor = [System.Drawing.Color]::White
    $lblHead.Font      = New-Object System.Drawing.Font('Segoe UI Semibold', 13)
    $lblHead.AutoSize  = $false
    $lblHead.Dock      = 'Fill'
    $lblHead.Padding   = New-Object System.Windows.Forms.Padding(12, 0, 0, 0)
    $lblHead.TextAlign = 'MiddleLeft'
    $pHead.Controls.Add($lblHead)

    # Content panel
    $pContent = New-Object System.Windows.Forms.Panel
    $pContent.Dock    = 'Fill'
    $pContent.Padding = New-Object System.Windows.Forms.Padding(24, 16, 24, 8)

    $nl = [Environment]::NewLine
    $lblInfo = New-Object System.Windows.Forms.Label
    $lblInfo.Dock     = 'Top'
    $lblInfo.AutoSize = $false
    $lblInfo.Height   = 56
    $lblInfo.Font     = New-Object System.Drawing.Font('Segoe UI', 10)
    $lblInfo.Text     = "Namn:      $FullName${nl}Datum:     $SignDate"

    $lblTabsLabel = New-Object System.Windows.Forms.Label
    $lblTabsLabel.Dock     = 'Top'
    $lblTabsLabel.AutoSize = $false
    $lblTabsLabel.Height   = 26
    $lblTabsLabel.Font     = New-Object System.Drawing.Font('Segoe UI Semibold', 9.5)
    $lblTabsLabel.Text     = 'Flikar som kommer signeras:'

    $lblTabs = New-Object System.Windows.Forms.Label
    $lblTabs.Dock     = 'Top'
    $lblTabs.AutoSize = $false
    $lblTabs.Font     = New-Object System.Drawing.Font('Segoe UI', 9.5)
    $lblTabs.Padding  = New-Object System.Windows.Forms.Padding(12, 0, 0, 0)

    if ($safeTargets.Count -eq 0) {
        $lblTabs.Height    = 26
        $lblTabs.Text      = '(inga flikar identifierade)'
        $lblTabs.ForeColor = [System.Drawing.Color]::FromArgb(180, 80, 80)
    } else {
        $tabLines = @()
        foreach ($t in $safeTargets) {
            $tabLines += [char]0x2713 + "  $t"
        }
        $lblTabs.Height = [Math]::Max(26, $safeTargets.Count * 22)
        $lblTabs.Text   = ($tabLines -join $nl)
        $lblTabs.ForeColor = [System.Drawing.Color]::FromArgb(40, 120, 40)
    }

    $pContent.Controls.Add($lblTabs)
    $pContent.Controls.Add($lblTabsLabel)
    $pContent.Controls.Add($lblInfo)

    # Button panel — FlowLayoutPanel höger-till-vänster (oberoende av fönsterstorlek)
    $pBtn = New-Object System.Windows.Forms.FlowLayoutPanel
    $pBtn.Dock          = 'Bottom'
    $pBtn.Height        = 52
    $pBtn.FlowDirection = 'RightToLeft'
    $pBtn.Padding       = New-Object System.Windows.Forms.Padding(16, 8, 16, 8)
    $pBtn.WrapContents  = $false

    $btnNo = New-Object System.Windows.Forms.Button
    $btnNo.Text         = 'Avbryt'
    $btnNo.Width        = 100
    $btnNo.Height       = 34
    $btnNo.Margin       = New-Object System.Windows.Forms.Padding(0)
    $btnNo.DialogResult = [System.Windows.Forms.DialogResult]::No

    $btnYes = New-Object System.Windows.Forms.Button
    $btnYes.Text         = 'Ja, signera'
    $btnYes.Width        = 120
    $btnYes.Height       = 34
    $btnYes.Margin       = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $btnYes.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    try { Set-AccentButton $btnYes -Primary } catch {
        $btnYes.BackColor = [System.Drawing.Color]::SteelBlue
        $btnYes.ForeColor = [System.Drawing.Color]::White
        $btnYes.FlatStyle = 'Flat'
    }

    # RightToLeft: först tillagd = längst till höger
    $pBtn.Controls.Add($btnNo)
    $pBtn.Controls.Add($btnYes)

    $dlg.AcceptButton = $btnYes
    $dlg.CancelButton = $btnNo
    $dlg.Controls.Add($pContent)
    $dlg.Controls.Add($pBtn)
    $dlg.Controls.Add($pHead)

    $res = $dlg.ShowDialog()
    return ($res -eq [System.Windows.Forms.DialogResult]::Yes)
}

# =============================================================
# GDP-SAFE
# =============================================================

function Save-ForensicSnapshot {
    param(
        [Parameter(Mandatory=$true)][string]$SourcePath,
        [Parameter(Mandatory=$true)][string]$Reason,
        [Parameter(Mandatory=$false)][string]$AuditDir,
        [Parameter(Mandatory=$false)][hashtable]$Details = @{}
    )
    try {
        if (-not $AuditDir) { $AuditDir = Join-Path $PSScriptRoot 'audit' }
        $forensicDir = Join-Path $AuditDir 'forensics'
        if (-not (Test-Path -LiteralPath $forensicDir)) {
            New-Item -ItemType Directory -Path $forensicDir -Force | Out-Null
        }

        $ts = (Get-Date).ToString('yyyyMMdd_HHmmss')
        $leaf = Split-Path $SourcePath -Leaf
        $snapName = "${ts}_${env:USERNAME}_${leaf}"
        $snapPath = Join-Path $forensicDir $snapName

        if (Test-Path -LiteralPath $SourcePath) {
            Copy-Item -LiteralPath $SourcePath -Destination $snapPath -Force -ErrorAction Stop
        }

        $logPath = Join-Path $forensicDir "${ts}_${env:USERNAME}_fail.log"
        $logLines = @(
            "SIGNATURE LOG"
            "======================"
            "Tidpunkt:    $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
            "Användare:   $env:USERNAME"
            "Dator:       $env:COMPUTERNAME"
            "Källfil:     $SourcePath"
            "Snapshot:    $snapPath"
            "Orsak:       $Reason"
        )
        foreach ($k in $Details.Keys) {
            $logLines += "${k}: $($Details[$k])"
        }
        Set-Content -LiteralPath $logPath -Value ($logLines -join "`r`n") -Encoding UTF8

        return $snapPath
    } catch {
        try { Gui-Log "⚠️ Kunde inte spara snapshot: $($_.Exception.Message)" 'Warn' } catch {}
        return $null
    }
}

function Verify-SealTestSignatures {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$ExpectedText,
        [Parameter(Mandatory=$true)][string]$SignatureCell,
        [Parameter(Mandatory=$true)][string]$ActiveCheckCell,
        [Parameter(Mandatory=$true)][int]$ExpectedWritten
    )

    $result = [pscustomobject]@{
        OK             = $false
        SheetsChecked  = 0
        SheetsVerified = 0
        Mismatches     = New-Object System.Collections.Generic.List[string]
        Error          = $null
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        $result.Error = "Filen finns inte: $Path"
        return $result
    }

    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
        foreach ($ws in $pkg.Workbook.Worksheets) {
            if ($ws.Name -eq 'Worksheet Instructions') { continue }
            $h3 = ($ws.Cells[$ActiveCheckCell].Text + '').Trim()
            if ($h3 -match '^[0-9]') {
                $result.SheetsChecked++
                $actual = ($ws.Cells[$SignatureCell].Text + '').Trim()
                if ($actual -eq $ExpectedText) {
                    $result.SheetsVerified++
                } else {
                    [void]$result.Mismatches.Add("$($ws.Name): Förväntade='$ExpectedText' Faktisk='$actual'")
                }
            }
            elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/?A|NA|Tomt( innehåll)?)$') {
                break
            }
        }

        if ($result.Mismatches.Count -eq 0 -and $result.SheetsVerified -ge $ExpectedWritten) {
            $result.OK = $true
        }
    } catch {
        $result.Error = $_.Exception.Message
    } finally {
        try { if ($pkg) { $pkg.Dispose() } } catch {}
    }
    return $result
}

function Verify-WorksheetSignatures {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][object[]]$WrittenCells
    )

    $result = [pscustomobject]@{
        OK             = $false
        CellsChecked   = 0
        CellsVerified  = 0
        Mismatches     = New-Object System.Collections.Generic.List[string]
        Error          = $null
    }

    if (-not $WrittenCells -or $WrittenCells.Count -eq 0) {
        $result.OK = $true
        return $result
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        $result.Error = "Filen finns inte: $Path"
        return $result
    }

    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))

        foreach ($wc in $WrittenCells) {
            $result.CellsChecked++
            $ws = $pkg.Workbook.Worksheets[$wc.Sheet]
            if (-not $ws) {
                [void]$result.Mismatches.Add("$($wc.Sheet) $($wc.Col)$($wc.Row): Fliken hittades inte")
                continue
            }

            $cellAddr = "$($wc.Col)$($wc.Row)"
            $actual = ($ws.Cells[$cellAddr].Text + '').Trim()
            $expected = ($wc.Value + '').Trim()

            if ($actual -eq $expected) {
                $result.CellsVerified++
            } else {
                [void]$result.Mismatches.Add("$($wc.Sheet) ${cellAddr}: Förväntade='$expected' Faktisk='$actual'")
            }
        }

        $result.OK = ($result.Mismatches.Count -eq 0 -and $result.CellsVerified -eq $WrittenCells.Count)
    } catch {
        $result.Error = $_.Exception.Message
    } finally {
        try { if ($pkg) { $pkg.Dispose() } } catch {}
    }
    return $result
}
